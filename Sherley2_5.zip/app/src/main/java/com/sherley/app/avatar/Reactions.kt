package com.sherley.app.avatar

import com.sherley.app.companion.Mood
import com.sherley.app.companion.NeedsDelta
import kotlin.random.Random

/** How you touched her. SPAM is made by the app when you tap again and again. */
enum class TouchKind { TAP, DOUBLE_TAP, STROKE, SPAM }

/** What a reaction does to her mood: need changes plus short pushes toward certain moods. */
enum class Tone(val needs: NeedsDelta, val boosts: Map<Mood, Float>) {
    AFFECTION(NeedsDelta(comfort = 6f, company = 3f, respect = 1f), mapOf(Mood.AFFECTIONATE to 0.5f, Mood.HAPPY to 0.3f, Mood.CONTENT to 0.25f, Mood.SHY to 0.15f)),
    COMFORT(NeedsDelta(comfort = 10f, company = 4f), mapOf(Mood.CONTENT to 0.4f, Mood.RELAXED to 0.3f, Mood.AFFECTIONATE to 0.3f)),
    PLAYFUL(NeedsDelta(stimulation = 4f, company = 2f), mapOf(Mood.PLAYFUL to 0.45f, Mood.GIDDY to 0.25f, Mood.HAPPY to 0.2f)),
    TICKLISH(NeedsDelta(energy = 3f, stimulation = 3f, comfort = 1f), mapOf(Mood.GIDDY to 0.4f, Mood.PLAYFUL to 0.3f)),
    STARTLED(NeedsDelta(stimulation = 3f, comfort = -1f), mapOf(Mood.CURIOUS to 0.25f, Mood.NERVOUS to 0.15f)),
    ANNOYED(NeedsDelta(comfort = -6f, respect = -5f), mapOf(Mood.ANNOYED to 0.5f, Mood.GRUMPY to 0.3f, Mood.SULKY to 0.15f)),
    IRRITATED(NeedsDelta(comfort = -3f, respect = -3f), mapOf(Mood.ANNOYED to 0.3f, Mood.STUBBORN to 0.2f, Mood.DETERMINED to 0.2f)),
    SHY(NeedsDelta(comfort = 1f), mapOf(Mood.SHY to 0.4f, Mood.EMBARRASSED to 0.35f)),
    SMUG(NeedsDelta(confidence = 5f, respect = 2f), mapOf(Mood.COCKY to 0.4f, Mood.PROUD to 0.35f, Mood.SASSY to 0.2f)),
    CURIOUS(NeedsDelta(stimulation = 2f, company = 2f), mapOf(Mood.CURIOUS to 0.25f, Mood.HAPPY to 0.1f)),
    SLEEPY(NeedsDelta(comfort = 4f, energy = -3f), mapOf(Mood.SLEEPY to 0.3f, Mood.COZY to 0.3f, Mood.CONTENT to 0.2f)),
    EXCITED(NeedsDelta(energy = 4f, stimulation = 4f, company = 3f), mapOf(Mood.EXCITED to 0.4f, Mood.GIDDY to 0.3f, Mood.HAPPY to 0.3f)),
    JOY(NeedsDelta(company = 5f, comfort = 3f), mapOf(Mood.HAPPY to 0.4f, Mood.DELIGHTED to 0.3f, Mood.AFFECTIONATE to 0.15f)),
}

/**
 * One body reaction: a face flash, a short arm/head gesture, a line of speech, and a mood effect.
 * [moods] = only used when she is in one of these moods (these beat the generic reaction for the same touch).
 * [steps] gets the side that was touched: +1 = her left (screen right), -1 = her right.
 */
class Reaction(
    val id: String,
    val regions: Set<Region>,
    val kind: TouchKind,
    val moods: Set<Mood>? = null,
    val tone: Tone,
    /** How the language model hears about it ("patted your head"). */
    val note: String,
    val lines: List<String>,
    val face: Face? = null,
    val steps: (Int) -> List<Step>,
)

/** All 36 reactions. Add your own to the list at the bottom of this file. */
object Reactions {

    private val HEAD = setOf(Region.HEAD)
    private val NECK = setOf(Region.NECK)
    private val SHOULDERS = setOf(Region.SHOULDER_L, Region.SHOULDER_R)
    private val ARMS = setOf(Region.UPPER_ARM_L, Region.UPPER_ARM_R)
    private val ELBOWS = setOf(Region.ELBOW_L, Region.ELBOW_R)
    private val FOREARMS = setOf(Region.FOREARM_L, Region.FOREARM_R)
    private val HANDS = setOf(Region.HAND_L, Region.HAND_R)

    private val SAD = setOf(Mood.SAD, Mood.LONELY, Mood.DISAPPOINTED, Mood.HOMESICK, Mood.WORRIED)
    private val GRUMPY = setOf(Mood.ANNOYED, Mood.GRUMPY, Mood.SULKY, Mood.FRUSTRATED, Mood.STUBBORN, Mood.JEALOUS)
    private val SLEEPY = setOf(Mood.SLEEPY, Mood.TIRED, Mood.LAZY)
    private val HYPED = setOf(Mood.EXCITED, Mood.HYPER, Mood.GIDDY, Mood.EAGER, Mood.DELIGHTED)
    private val SMUGGY = setOf(Mood.COCKY, Mood.PROUD, Mood.SASSY)
    private val BASHFUL = setOf(Mood.SHY, Mood.EMBARRASSED, Mood.NERVOUS)
    private val FOCUSED = setOf(Mood.CURIOUS, Mood.INTRIGUED, Mood.SCHEMING, Mood.THOUGHTFUL, Mood.SUSPICIOUS, Mood.DETERMINED)
    private val LONELY = setOf(Mood.LONELY, Mood.SAD)
    private val BORED = setOf(Mood.BORED, Mood.DISTRACTED)

    /** +1 for a left-side region, -1 for right, a random side for the middle ones (head, neck). */
    fun sideOf(region: Region, random: Random = Random.Default): Int = when {
        region.name.endsWith("_L") -> 1
        region.name.endsWith("_R") -> -1
        else -> if (random.nextBoolean()) 1 else -1
    }

    /** The best reaction for this touch: mood-specific ones first, then the generic one, then any for that part. */
    fun pick(region: Region, kind: TouchKind, mood: Mood, random: Random = Random.Default): Reaction? {
        val forRegion = all.filter { region in it.regions }
        val exact = forRegion.filter { it.kind == kind }
        val moodSpecific = exact.filter { it.moods != null && mood in it.moods }
        val pool = moodSpecific.ifEmpty { exact.filter { it.moods == null } }
            .ifEmpty { forRegion.filter { it.kind == TouchKind.TAP && it.moods == null } }
            .ifEmpty { forRegion }
        return pool.randomOrNull(random)
    }

    private fun hold(ms: Long) = Step(ms) { it }
    private fun step(ms: Long, f: (Pose) -> Pose) = Step(ms, f)

    // Faces (see FaceMap for what the numbers mean)
    private val smile = Face(joy = 0.8f)
    private val bigSmile = Face(joy = 1f, surprised = 0.2f)
    private val gasp = Face(surprised = 1f)
    private val glare = Face(angry = 0.8f)
    private val blush = Face(joy = 0.4f, sad = 0.2f, surprised = 0.3f)
    private val dreamy = Face(relaxed = 0.9f, eyesClosed = 0.6f)
    private val teary = Face(sad = 0.6f, relaxed = 0.4f, eyesClosed = 0.3f)
    private val smirk = Face(joy = 0.5f, angry = 0.3f)
    private val giggle = Face(joy = 1f, eyesClosed = 0.4f)

    val all: List<Reaction> = listOf(

        // ---------------- HEAD ----------------
        Reaction("head_pat", HEAD, TouchKind.STROKE, null, Tone.AFFECTION, "patted your head",
            listOf("Hehe, I'm a detective, not a cat!", "Careful, you'll mess up my hair. ...Keep going though.", "Observation: head pats improve my mood by about 40 percent."),
            smile) { _ -> listOf(step(500) { it.withHead(V.head(0f, -10f)) }, step(900) { it.withHead(V.head(4f, -12f)) }, hold(300)) },
        Reaction("head_pat_sad", HEAD, TouchKind.STROKE, SAD, Tone.COMFORT, "gently patted your head while you were low",
            listOf("...thanks. I needed that.", "That's nice. Stay a moment?"),
            teary) { _ -> listOf(step(700) { it.withHead(V.head(0f, -14f)) }, step(1400) { it.withHead(V.head(3f, -16f)) }, hold(300)) },
        Reaction("head_pat_annoyed", HEAD, TouchKind.STROKE, GRUMPY, Tone.IRRITATED, "patted your head while you were in a mood",
            listOf("Hmph. ...Fine. Two more seconds.", "Don't think this fixes everything. It helps a little."),
            Face(angry = 0.3f, relaxed = 0.3f)) { s -> listOf(step(450) { it.withHead(V.head(-25f * s, 5f)) }, step(900) { it.withHead(V.head(-5f * s, -6f)) }, hold(300)) },
        Reaction("head_pat_sleepy", HEAD, TouchKind.STROKE, SLEEPY, Tone.SLEEPY, "patted your head while you were sleepy",
            listOf("Mmm. Keep doing that and I'll fall asleep.", "Zzz... oh. Hi."),
            dreamy) { _ -> listOf(step(800) { it.withHead(V.head(0f, -22f)) }, step(900) { it.withHead(V.head(5f, -8f)) }, step(900) { it.withHead(V.head(0f, -22f)) }, hold(200)) },
        Reaction("head_pat_excited", HEAD, TouchKind.STROKE, HYPED, Tone.EXCITED, "patted your head while you were buzzing",
            listOf("Yes! More! I'm basically vibrating!", "Pat accepted with maximum enthusiasm!"),
            bigSmile) { s -> listOf(
                step(250) { it.withHead(V.head(0f, 12f)).arm(s, upper = V.arm(s, 35f, 10f)).arm(-s, upper = V.arm(-s, 35f, 10f)) },
                step(250) { it.withHead(V.head(0f, -8f)) }, step(250) { it.withHead(V.head(0f, 12f)) }, step(250) { it.withHead(V.head(0f, -8f)) }, hold(200)) },
        Reaction("head_pat_smug", HEAD, TouchKind.STROKE, SMUGGY, Tone.SMUG, "patted your head and she soaked it up",
            listOf("Naturally. A mind like this deserves appreciation.", "Yes, yes, pat the genius."),
            smirk) { _ -> listOf(step(500) { it.withHead(V.head(8f, 14f)) }, step(1000) { it.withHead(V.head(8f, 14f)) }, hold(200)) },
        Reaction("head_poke", HEAD, TouchKind.TAP, null, Tone.PLAYFUL, "poked your forehead",
            listOf("Hey! Forehead's off limits, that's where the genius lives.", "Poke detected. Motive?", "Yes? Do you have a case, or just a finger?"),
            gasp) { _ -> listOf(step(150) { it.withHead(V.head(0f, 22f)) }, step(500) { it.withHead(V.head(0f, 4f)) }, hold(100)) },
        Reaction("head_poke_bored", HEAD, TouchKind.TAP, BORED, Tone.PLAYFUL, "poked your head while you were bored",
            listOf("Oh, finally, entertainment! Do it again.", "A poke! The first interesting thing all day."),
            bigSmile) { s -> listOf(step(250) { it.withHead(V.head(15f * s, 8f)) }, step(500) { it.withHead(V.head(-10f * s, 4f)) }, hold(200)) },
        Reaction("head_poke_sleepy", HEAD, TouchKind.TAP, SLEEPY, Tone.STARTLED, "poked your head and woke you up",
            listOf("Wha— I'm awake! I was just resting my eyes.", "I wasn't sleeping. I was deducing. With my eyes closed."),
            gasp) { _ -> listOf(step(150) { it.withHead(V.head(0f, 25f)) }, step(600) { it.withHead(V.head(0f, 0f)) }, hold(100)) },
        Reaction("head_poke_shy", HEAD, TouchKind.TAP, BASHFUL, Tone.SHY, "poked your head and flustered you",
            listOf("Um! You startled me. I'm fine. I'm totally fine.", "Hey! ...Don't look at me like that."),
            blush) { s -> listOf(step(300) { it.withHead(V.head(-20f * s, -12f)).arm(s, upper = V.arm(s, 40f, 40f), lower = V.arm(s, 150f, 50f)) }, step(1100) { it }, hold(200)) },
        Reaction("head_double", HEAD, TouchKind.DOUBLE_TAP, null, Tone.CURIOUS, "double-tapped your head",
            listOf("Boop, boop. Is that a code? I'll crack it.", "Two taps. Morse for 'hello'? I'm good at this."),
            gasp) { _ -> listOf(step(250) { it.withHead(V.head(0f, 20f)) }, step(300) { it.withHead(V.head(0f, -6f)) }, step(300) { it.withHead(V.head(0f, 14f)) }, hold(200)) },
        Reaction("head_spam", HEAD, TouchKind.SPAM, null, Tone.ANNOYED, "poked your head again and again",
            listOf("Okay, that's enough poking! I'm filing a complaint.", "Seven pokes. I counted. Stop it!", "My forehead is not a doorbell!"),
            glare) { s -> listOf(step(250) { it.arm(s, upper = V.arm(s, 80f, 60f), lower = V.arm(s, 120f, 70f)).withHead(V.head(10f * s, 5f)) }, step(300) { it.arm(s, upper = V.arm(s, 50f, 30f), lower = V.arm(s, 60f, 60f)) }, hold(400)) },
        Reaction("head_spam_playful", HEAD, TouchKind.SPAM, setOf(Mood.PLAYFUL, Mood.MISCHIEVOUS, Mood.GIDDY, Mood.HYPER), Tone.PLAYFUL, "kept poking your head and she fought back playfully",
            listOf("Oh, it's ON. Prepare for a counter-poke!", "You asked for it, partner!"),
            giggle) { s -> listOf(step(250) { it.arm(s, upper = V.arm(s, 70f, 70f), lower = V.arm(s, 90f, 80f)).arm(-s, upper = V.arm(-s, 70f, 70f), lower = V.arm(-s, 90f, 80f)) }, step(250) { it.arm(s, lower = V.arm(s, 60f, 80f)) }, step(250) { it.arm(-s, lower = V.arm(-s, 60f, 80f)) }, hold(300)) },

        // ---------------- NECK ----------------
        Reaction("neck_tap", NECK, TouchKind.TAP, null, Tone.TICKLISH, "tapped the back of your neck",
            listOf("Eep! That tickles!", "Hehe, careful, ticklish zone."),
            giggle) { s -> listOf(step(250) { it.withHead(V.norm(0.45f * s, -0.1f, 0.9f)).arm(s, upper = V.arm(s, 12f)) }, step(600) { it }, hold(200)) },
        Reaction("neck_stroke", NECK, TouchKind.STROKE, null, Tone.AFFECTION, "stroked your neck lightly",
            listOf("Ooh, shivers. The good kind.", "Okay, that's surprisingly relaxing."),
            dreamy) { s -> listOf(step(500) { it.withHead(V.head(-18f * s, -8f)) }, step(900) { it.withHead(V.head(-22f * s, -12f)) }, hold(300)) },
        Reaction("neck_double", NECK, TouchKind.DOUBLE_TAP, null, Tone.IRRITATED, "double-tapped your neck",
            listOf("Hey! Personal space, partner.", "I noticed that. I notice everything."),
            Face(surprised = 0.6f, angry = 0.3f)) { s -> listOf(step(200) { it.withHead(V.head(30f * s, 0f)).arm(s, upper = V.arm(s, 60f, 20f)).arm(-s, upper = V.arm(-s, 60f, 20f)) }, step(600) { it }, hold(200)) },

        // ---------------- SHOULDERS ----------------
        Reaction("shoulder_tap", SHOULDERS, TouchKind.TAP, null, Tone.CURIOUS, "tapped your shoulder",
            listOf("Hm? I'm here.", "Tap noted. What did you want to say?", "Yes, partner?"),
            smile) { s -> listOf(step(300) { it.withHead(V.head(35f * s, 0f)) }, step(900) { it.withHead(V.head(35f * s, 3f)) }, hold(200)) },
        Reaction("shoulder_tap_focus", SHOULDERS, TouchKind.TAP, FOCUSED, Tone.IRRITATED, "tapped your shoulder while you were concentrating",
            listOf("Shh, I'm mid-deduction!", "One second, I'm nearly there. Don't break the thread."),
            Face(angry = 0.4f, surprised = 0.2f)) { s -> listOf(step(250) { it.arm(s, upper = V.arm(s, 50f, 25f)) }, step(500) { it }, hold(200)) },
        Reaction("shoulder_tap_lonely", SHOULDERS, TouchKind.TAP, LONELY, Tone.JOY, "tapped your shoulder when you were feeling alone",
            listOf("Oh! You're here. Good. I was getting wistful.", "Hey, you. ...I'm glad you tapped."),
            bigSmile) { s -> listOf(step(300) { it.withHead(V.head(30f * s, 5f)) }, step(300) { it.withHead(V.head(0f, 3f)) }, hold(400)) },
        Reaction("shoulder_double", SHOULDERS, TouchKind.DOUBLE_TAP, null, Tone.CURIOUS, "double-tapped your shoulder",
            listOf("Twice? That's either urgent or you're bored. Which one?", "Okay, I'm listening. What's up?"),
            Face(surprised = 0.5f, joy = 0.3f)) { s -> listOf(step(300) { it.withHead(V.head(30f * s, 4f)).arm(s, upper = V.arm(s, 55f, 10f), lower = V.arm(s, 75f, 20f)).arm(-s, upper = V.arm(-s, 55f, 10f), lower = V.arm(-s, 75f, 20f)) }, step(800) { it }, hold(200)) },
        Reaction("shoulder_stroke", SHOULDERS, TouchKind.STROKE, null, Tone.COMFORT, "rubbed your shoulder",
            listOf("Mmm, that helps. I carry a lot of deductions up there.", "Okay, you can keep doing that."),
            dreamy) { s -> listOf(step(600) { it.withHead(V.head(-14f * s, -8f)) }, step(1000) { it.withHead(V.head(-16f * s, -10f)) }, hold(300)) },
        Reaction("shoulder_spam", SHOULDERS, TouchKind.SPAM, null, Tone.ANNOYED, "tapped your shoulder over and over",
            listOf("Stop it! I heard you the first time!", "If you tap me once more, I'm billing you."),
            glare) { s -> listOf(step(200) { it.arm(s, upper = V.arm(s, 70f, 50f), lower = V.arm(s, 110f, 60f)).withHead(V.head(35f * s, 0f)) }, step(300) { it.arm(s, upper = V.arm(s, 40f, 10f)) }, hold(400)) },

        // ---------------- UPPER ARMS ----------------
        Reaction("arm_tap", ARMS, TouchKind.TAP, null, Tone.CURIOUS, "tapped your arm",
            listOf("Hm? Something on my sleeve?", "You rang?"),
            smile) { s -> listOf(step(300) { it.withHead(V.head(25f * s, -25f)) }, step(700) { it }, hold(200)) },
        Reaction("arm_stroke", ARMS, TouchKind.STROKE, null, Tone.AFFECTION, "stroked your arm",
            listOf("That's nice. Friendly. I approve.", "Aw. Okay, you can stay."),
            smile) { s -> listOf(step(500) { it.arm(s, upper = V.arm(s, 14f)) }, step(900) { it.withHead(V.head(-10f * s, -6f)) }, hold(300)) },
        Reaction("arm_stroke_worried", ARMS, TouchKind.STROKE, setOf(Mood.WORRIED, Mood.NERVOUS), Tone.COMFORT, "stroked your arm to calm you",
            listOf("Okay. Breathing. That actually helps.", "Thanks. I needed someone to say 'it's fine' without words."),
            Face(sad = 0.2f, relaxed = 0.6f)) { s -> listOf(step(700) { it.withHead(V.head(0f, -10f)).arm(s, upper = V.arm(s, 10f)) }, step(1000) { it }, hold(300)) },
        Reaction("arm_spam", ARMS, TouchKind.SPAM, null, Tone.TICKLISH, "kept poking your arm and she squirmed",
            listOf("Hahaha, stop! I'm ticklish there!", "Okay okay! Mercy! Mercy!"),
            giggle) { s -> listOf(step(200) { it.arm(s, upper = V.arm(s, 4f), lower = V.arm(s, 10f, 20f)).withHead(V.head(-15f * s, 10f)) }, step(250) { it.withHead(V.head(10f * s, 10f)) }, step(250) { it.withHead(V.head(-12f * s, 8f)) }, hold(300)) },
        Reaction("arm_double", ARMS, TouchKind.DOUBLE_TAP, SMUGGY + HYPED, Tone.SMUG, "double-tapped your arm and she flexed",
            listOf("Yes, those are detective muscles. Very rare.", "Flex check! ...Okay, it's mostly brain."),
            smirk) { s -> listOf(step(350) { it.arm(s, upper = V.arm(s, 85f, 0f), lower = V.arm(s, 170f, 0f)) }, step(900) { it }, hold(200)) },

        // ---------------- ELBOWS ----------------
        Reaction("elbow_tap", ELBOWS, TouchKind.TAP, null, Tone.STARTLED, "tapped your elbow",
            listOf("Ooh, funny bone! Tingly!", "Careful with the elbow, it zings."),
            Face(surprised = 0.5f, joy = 0.4f)) { s -> listOf(step(150) { it.arm(s, lower = V.arm(s, 100f, 30f)) }, step(500) { it }, hold(100) ) },
        Reaction("elbow_double", ELBOWS, TouchKind.DOUBLE_TAP, null, Tone.PLAYFUL, "double-tapped your elbow",
            listOf("Hey, hands off the elbow. Playful, but hands off.", "Nope! Arm pulled back. Too slow, partner!"),
            giggle) { s -> listOf(step(200) { it.arm(s, upper = V.arm(s, 20f, -20f), lower = V.arm(s, 140f, -10f)) }, step(600) { it }, hold(100)) },
        Reaction("elbow_stroke", ELBOWS, TouchKind.STROKE, null, Tone.AFFECTION, "stroked your elbow",
            listOf("Okay, that's an oddly specific compliment.", "Mm, friendly. Fine."),
            smile) { s -> listOf(step(500) { it.arm(s, lower = V.arm(s, 55f, 40f)) }, step(800) { it }, hold(100)) },

        // ---------------- FOREARMS ----------------
        Reaction("forearm_tap", FOREARMS, TouchKind.TAP, null, Tone.CURIOUS, "tapped your forearm",
            listOf("Yes? I'm all ears. Well, and forearms.", "Hm, you need my attention?"),
            smile) { s -> listOf(step(300) { it.arm(s, lower = V.arm(s, 95f, 45f)).withHead(V.head(20f * s, -5f)) }, step(700) { it }, hold(100)) },
        Reaction("forearm_stroke", FOREARMS, TouchKind.STROKE, null, Tone.AFFECTION, "stroked your forearm",
            listOf("That's calming, actually.", "Mm. Okay. Good pal behavior."),
            Face(joy = 0.5f, relaxed = 0.5f)) { s -> listOf(step(600) { it.arm(s, lower = V.arm(s, 40f, 30f)) }, step(800) { it }, hold(100)) },

        // ---------------- HANDS ----------------
        Reaction("hand_tap", HANDS, TouchKind.TAP, null, Tone.JOY, "tapped your hand",
            listOf("Hi there! Yes, that's a wave.", "Hello, hello. Hand received."),
            smile) { s -> listOf(
                step(300) { it.arm(s, upper = V.arm(s, 95f, 10f), lower = V.arm(s, 160f, 10f)) },
                step(250) { it.arm(s, lower = V.arm(s, 135f, 10f)) }, step(250) { it.arm(s, lower = V.arm(s, 165f, 10f)) }, step(250) { it.arm(s, lower = V.arm(s, 135f, 10f)) }, hold(200)) },
        Reaction("hand_double", HANDS, TouchKind.DOUBLE_TAP, null, Tone.EXCITED, "double-tapped your hand for a high five",
            listOf("High five! Top case, partner!", "Up high! ...Too slow? Kidding."),
            bigSmile) { s -> listOf(step(300) { it.arm(s, upper = V.arm(s, 150f, 10f), lower = V.arm(s, 170f, 10f)) }, step(700) { it }, hold(200)) },
        Reaction("hand_stroke", HANDS, TouchKind.STROKE, null, Tone.SHY, "stroked your hand",
            listOf("Oh. Um. That's... fine. Friendly. Very friendly.", "Hey, careful, I'll get flustered."),
            blush) { s -> listOf(step(350) { it.arm(s, upper = V.arm(s, 30f, 50f), lower = V.arm(s, 140f, 50f)).withHead(V.head(-15f * s, -10f)) }, step(1000) { it }, hold(200)) },
        Reaction("hand_spam", HANDS, TouchKind.SPAM, null, Tone.ANNOYED, "kept poking your hand",
            listOf("Stop poking my hand! I need it for deducing!", "Enough! Shaking you off!"),
            glare) { s -> listOf(step(150) { it.arm(s, upper = V.arm(s, 60f, 20f), lower = V.arm(s, 110f, 30f)) }, step(150) { it.arm(s, lower = V.arm(s, 150f, 30f)) }, step(150) { it.arm(s, lower = V.arm(s, 100f, 30f)) }, step(150) { it.arm(s, lower = V.arm(s, 150f, 30f)) }, hold(300)) },
    )
}
