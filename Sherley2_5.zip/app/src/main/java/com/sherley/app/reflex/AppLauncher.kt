package com.sherley.app.reflex

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * Understands "open <app name>" typed in the chat and launches the app. No language model involved.
 * Accepts: open / launch / start, optional "please" and "the", optional trailing "app".
 */
object AppLauncher {

    sealed interface Result {
        data class Opened(val label: String) : Result
        data class NotFound(val name: String) : Result
    }

    private val pattern = Regex(
        """^\s*(?:please\s+)?(?:open|launch|start)\s+(?:up\s+)?(?:the\s+)?(.+?)(?:\s+app)?\s*[.!]?\s*$""",
        RegexOption.IGNORE_CASE,
    )

    /** The app name if the message is an open-command, otherwise null. */
    fun parse(message: String): String? =
        pattern.matchEntire(message)?.groupValues?.get(1)?.trim()?.takeIf { it.isNotBlank() }

    fun open(context: Context, name: String): Result {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != context.packageName }
            .map { it.loadLabel(pm).toString() to it.activityInfo.packageName }

        val q = name.lowercase()
        // Best match first: exact name, then name starts with it, then contains it, then it contains the name.
        val hit = apps.firstOrNull { it.first.lowercase() == q }
            ?: apps.filter { it.first.lowercase().startsWith(q) }.minByOrNull { it.first.length }
            ?: apps.filter { it.first.lowercase().contains(q) }.minByOrNull { it.first.length }
            ?: apps.filter { q.contains(it.first.lowercase()) && it.first.length >= 3 }.maxByOrNull { it.first.length }
            ?: return Result.NotFound(name)

        val launch = pm.getLaunchIntentForPackage(hit.second) ?: return Result.NotFound(name)
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(launch)
            Result.Opened(hit.first)
        } catch (e: Exception) {
            Result.NotFound(name)
        }
    }
}
