package com.sherley.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Amber = Color(0xFFFFC857)

private val SherleyColors = darkColorScheme(
    primary = Amber,
    onPrimary = Color(0xFF241A00),
    secondary = Color(0xFF8EC5FF),
    background = Color(0xFF26324F),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF34436A),
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFF3F5080),
    onSurfaceVariant = Color(0xFFE6ECFF),
)

/**
 * One brighter navy-and-amber theme. Change colors here.
 * The transparent Surface matters: it makes every Text default to the light "onBackground" color
 * (without it, text outside a Surface is black and unreadable on dark screens).
 */
@Composable
fun SherleyTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = SherleyColors) {
        Surface(color = Color.Transparent, contentColor = SherleyColors.onBackground, content = content)
    }
}
