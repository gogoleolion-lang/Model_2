package com.sherley.app.ai

import com.sherley.app.companion.ChatEvent
import com.sherley.app.config.AppConfig
import com.sherley.app.config.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.ConnectException

/**
 * Talks to the language model running inside the Thinai app, over its local OpenAI-style API:
 *   GET  {url}/v1/models            list installed models
 *   POST {url}/v1/chat/completions  one chat reply (not streamed)
 * No key is needed; a placeholder bearer token is sent anyway.
 *
 * Small local models are not always good at strict JSON, so the reply parser is forgiving:
 * it accepts JSON wrapped in other text, salvages a cut-off JSON reply, and falls back to
 * showing the plain text.
 */
class LocalLlmClient(
    private val settings: AppSettings,
    private val http: OkHttpClient,
) {

    /** Main chat call. systemPrompt = persona + context, turns = recent messages. */
    suspend fun chat(systemPrompt: String, turns: List<Turn>): ChatResult = withContext(Dispatchers.IO) {
        val messages = JSONArray().put(message("system", systemPrompt))
        for (t in tidy(turns)) messages.put(message(if (t.role == "user") "user" else "assistant", t.text))
        parseChatResult(complete(messages, AppConfig.CHAT_MAX_OUTPUT_TOKENS, AppConfig.CHAT_TEMPERATURE))
    }

    /** Plain text in, plain text out. Used for summarizing old conversations. */
    suspend fun plainText(prompt: String, maxTokens: Int = 500): String = withContext(Dispatchers.IO) {
        val messages = JSONArray().put(message("user", prompt))
        complete(messages, maxTokens, 0.3).trim()
    }

    /** Names of the models Thinai offers (empty if none are installed). */
    suspend fun listModels(): List<String> = withContext(Dispatchers.IO) { fetchModels() }

    // ---------------------------------------------------------------------
    // HTTP
    // ---------------------------------------------------------------------
    private fun baseUrl() = settings.localUrl.trim().trimEnd('/')

    private fun fetchModels(): List<String> {
        val request = Request.Builder().url("${baseUrl()}/v1/models").get().build()
        val raw = execute(request)
        val data = JSONObject(raw).optJSONArray("data") ?: return emptyList()
        return (0 until data.length()).mapNotNull { data.optJSONObject(it)?.optString("id")?.takeIf(String::isNotBlank) }
    }

    /** The model named in Settings, or the first one Thinai reports. */
    private fun resolveModel(): String {
        settings.localModel.trim().takeIf { it.isNotBlank() }?.let { return it }
        return fetchModels().firstOrNull()
            ?: throw ApiException("Thinai has no model available. Download one in Thinai, then pick it in the Server tab.")
    }

    private fun complete(messages: JSONArray, maxTokens: Int, temperature: Double): String {
        val body = JSONObject()
            .put("model", resolveModel())
            .put("messages", messages)
            .put("stream", false)
            .put("temperature", temperature)
            .put("max_tokens", maxTokens)

        val request = Request.Builder()
            .url("${baseUrl()}/v1/chat/completions")
            .header("Authorization", "Bearer local")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val json = JSONObject(execute(request))
        val content = json.optJSONArray("choices")?.optJSONObject(0)
            ?.optJSONObject("message")?.optString("content").orEmpty()
        val text = stripThinking(content).trim()
        if (text.isBlank()) {
            throw ApiException(
                "The local model returned an empty answer. It may still be loading, or it spent the whole " +
                    "token limit on hidden reasoning. Try again, or pick a non-reasoning model in Thinai.",
            )
        }
        return text
    }

    /** Sends the request and returns the body, turning every failure into a readable ApiException. */
    private fun execute(request: Request): String {
        return try {
            http.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) throw ApiException(errorMessage(raw, response.code))
                raw
            }
        } catch (e: ApiException) {
            throw e
        } catch (e: ConnectException) {
            throw ApiException(
                "Cannot reach Thinai at ${baseUrl()}. Open Thinai, go to the Server tab, start the server " +
                    "and select a model. Keep Thinai running in the background.",
            )
        } catch (e: IOException) {
            throw ApiException(Http.explain(e))
        } catch (e: org.json.JSONException) {
            throw ApiException("Thinai answered with something that is not JSON. Check the server URL in Settings.")
        }
    }

    private fun errorMessage(raw: String, code: Int): String {
        val message = try {
            val o = JSONObject(raw)
            val err = o.opt("error")
            when (err) {
                is JSONObject -> err.optString("message")
                is String -> err
                else -> ""
            }
        } catch (e: Exception) {
            raw.take(200)
        }
        return when {
            code == 404 -> "Thinai does not know that address or model (404). Check the model name in Settings. $message".trim()
            code == 503 || code == 409 -> "Thinai is busy or has no model loaded ($code). $message".trim()
            message.isNotBlank() -> "Thinai error $code: $message"
            else -> "Thinai error $code"
        }
    }

    // ---------------------------------------------------------------------
    // Reading the reply
    // ---------------------------------------------------------------------
    /** Removes <think>...</think> blocks that reasoning models (Qwen3, DeepSeek...) print. */
    private fun stripThinking(text: String): String {
        var t = text.replace(Regex("(?s)<think>.*?</think>"), "")
        val open = t.indexOf("<think>")
        if (open >= 0) t = t.substring(0, open) // reasoning was cut off, nothing usable after it
        return t
    }

    private fun parseChatResult(raw: String): ChatResult {
        val text = raw.trim()
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        if (start >= 0 && end > start) {
            try {
                val o = JSONObject(text.substring(start, end + 1))
                val reply = o.optString("reply").trim()
                if (reply.isNotBlank()) {
                    return ChatResult(
                        reply = reply,
                        events = readEvents(o.optJSONArray("events")),
                        facts = readStrings(o.optJSONArray("facts")).take(5),
                    )
                }
            } catch (e: Exception) {
                // fall through to the salvage attempts below
            }
        }
        return ChatResult(salvageReply(text), emptyList(), emptyList())
    }

    /** If the JSON was cut off (token limit), still pull out the reply text; otherwise show the text. */
    private fun salvageReply(text: String): String {
        val match = Regex("\"reply\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)").find(text)
        if (match != null) {
            try {
                val decoded = JSONObject("{\"x\":\"" + match.groupValues[1] + "\"}").getString("x").trim()
                if (decoded.isNotBlank()) return decoded
            } catch (e: Exception) {
                // use the plain text below
            }
        }
        return text.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
    }

    private fun readEvents(arr: JSONArray?): List<ChatEvent> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).mapNotNull { ChatEvent.fromTag(arr.optString(it)) }
    }

    private fun readStrings(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { arr.optString(it).trim() }.filter { it.isNotBlank() }
    }

    private fun message(role: String, content: String) =
        JSONObject().put("role", role).put("content", content)

    /** Most chat templates want turns that alternate and start with the user, so tidy the list first. */
    private fun tidy(turns: List<Turn>): List<Turn> {
        val merged = mutableListOf<Turn>()
        for (t in turns) {
            if (merged.isEmpty() && t.role != "user") continue
            if (merged.isNotEmpty() && merged.last().role == t.role) {
                merged[merged.lastIndex] = Turn(t.role, merged.last().text + "\n" + t.text)
            } else {
                merged += t
            }
        }
        return merged
    }
}
