package com.sherley.app.avatar

import com.sherley.app.companion.Mood

/** Face blend amounts, each 0..1. These are the six standard VRM expression presets. */
data class Face(
    val joy: Float = 0f,
    val angry: Float = 0f,
    val sad: Float = 0f,
    val relaxed: Float = 0f,
    val surprised: Float = 0f,
    val eyesClosed: Float = 0f,
) {
    fun scaled(k: Float) = Face(joy * k, angry * k, sad * k, relaxed * k, surprised * k, eyesClosed * k)
}

/** Turns a mood + intensity into a face. Edit the table to change how each mood looks. */
object FaceMap {

    fun face(mood: Mood, intensity: Float): Face {
        val k = 0.4f + 0.6f * intensity.coerceIn(0f, 1f)
        return base(mood).scaled(k)
    }

    private fun base(m: Mood): Face = when (m) {
        Mood.HAPPY -> Face(joy = 0.8f)
        Mood.CHEERFUL -> Face(joy = 0.9f)
        Mood.DELIGHTED -> Face(joy = 1f, surprised = 0.2f)
        Mood.PLAYFUL -> Face(joy = 0.7f, surprised = 0.1f)
        Mood.PROUD -> Face(joy = 0.5f, relaxed = 0.3f)
        Mood.GIDDY -> Face(joy = 1f, surprised = 0.15f)

        Mood.EXCITED -> Face(joy = 0.7f, surprised = 0.5f)
        Mood.EAGER -> Face(joy = 0.5f, surprised = 0.3f)
        Mood.MISCHIEVOUS -> Face(joy = 0.5f, angry = 0.25f)
        Mood.COCKY -> Face(joy = 0.4f, angry = 0.2f, relaxed = 0.2f)
        Mood.HYPER -> Face(joy = 0.8f, surprised = 0.5f)

        Mood.CURIOUS -> Face(surprised = 0.4f)
        Mood.INTRIGUED -> Face(surprised = 0.3f, relaxed = 0.1f)
        Mood.SCHEMING -> Face(joy = 0.3f, angry = 0.3f)
        Mood.THOUGHTFUL -> Face(relaxed = 0.5f)
        Mood.SUSPICIOUS -> Face(angry = 0.4f, surprised = 0.1f)
        Mood.DETERMINED -> Face(angry = 0.4f)

        Mood.RELAXED -> Face(relaxed = 0.9f)
        Mood.CONTENT -> Face(joy = 0.4f, relaxed = 0.6f)
        Mood.COZY -> Face(joy = 0.2f, relaxed = 0.8f, eyesClosed = 0.2f)
        Mood.DREAMY -> Face(relaxed = 0.7f, eyesClosed = 0.3f)
        Mood.NOSTALGIC -> Face(sad = 0.2f, relaxed = 0.5f)

        Mood.BORED -> Face(relaxed = 0.5f, eyesClosed = 0.3f)
        Mood.SLEEPY -> Face(relaxed = 0.6f, eyesClosed = 0.7f)
        Mood.LAZY -> Face(relaxed = 0.7f, eyesClosed = 0.4f)
        Mood.TIRED -> Face(sad = 0.2f, relaxed = 0.3f, eyesClosed = 0.5f)
        Mood.DISTRACTED -> Face(relaxed = 0.3f, surprised = 0.1f)

        Mood.SAD -> Face(sad = 0.9f)
        Mood.LONELY -> Face(sad = 0.7f, relaxed = 0.2f)
        Mood.DISAPPOINTED -> Face(sad = 0.6f, angry = 0.1f)
        Mood.HOMESICK -> Face(sad = 0.6f, relaxed = 0.3f)
        Mood.SULKY -> Face(sad = 0.4f, angry = 0.4f)

        Mood.ANNOYED -> Face(angry = 0.6f)
        Mood.GRUMPY -> Face(angry = 0.7f, sad = 0.1f)
        Mood.JEALOUS -> Face(angry = 0.4f, sad = 0.3f)
        Mood.FRUSTRATED -> Face(angry = 0.8f)
        Mood.STUBBORN -> Face(angry = 0.5f)

        Mood.EMBARRASSED -> Face(joy = 0.3f, sad = 0.2f, surprised = 0.3f)
        Mood.SHY -> Face(joy = 0.2f, sad = 0.3f)
        Mood.WORRIED -> Face(sad = 0.5f, surprised = 0.3f)
        Mood.NERVOUS -> Face(sad = 0.3f, surprised = 0.4f)
        Mood.AFFECTIONATE -> Face(joy = 0.6f, relaxed = 0.4f)
        Mood.SASSY -> Face(joy = 0.4f, angry = 0.3f)
    }
}

/** The stronger of two faces, expression by expression (used to flash a reaction over her mood face). */
fun Face.maxWith(o: Face) = Face(
    maxOf(joy, o.joy), maxOf(angry, o.angry), maxOf(sad, o.sad),
    maxOf(relaxed, o.relaxed), maxOf(surprised, o.surprised), maxOf(eyesClosed, o.eyesClosed),
)

/**
 * A gentler version of a face: only the two strongest expressions stay, scaled by [strength] (0..1) and capped.
 * Blending many expressions at once can distort a model's face, so this keeps it natural.
 */
fun Face.gentle(strength: Float): Face {
    if (strength <= 0f) return Face()
    val parts = floatArrayOf(joy, angry, sad, relaxed, surprised, eyesClosed)
    val keep = parts.indices.filter { parts[it] > 0.12f }.sortedByDescending { parts[it] }.take(2).toSet()
    fun v(i: Int) = if (i in keep) (parts[i] * strength).coerceAtMost(0.6f) else 0f
    return Face(v(0), v(1), v(2), v(3), v(4), v(5))
}
