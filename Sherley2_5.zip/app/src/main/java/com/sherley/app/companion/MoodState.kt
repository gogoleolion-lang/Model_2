package com.sherley.app.companion

import org.json.JSONObject

/** Everything the mood engine needs to remember between app launches. */
data class MoodState(
    val needs: Needs,
    val mood: Mood,
    /** 0.2 (a hint of the mood) .. 1.0 (the mood in full force) */
    val intensity: Float,
    /** Temporary pushes toward certain moods caused by recent events. Fade with time. */
    val boosts: Map<Mood, Float>,
    val lastMessageAt: Long,
    val lastTickAt: Long,
) {
    fun toJson(): String {
        val b = JSONObject()
        for ((m, v) in boosts) b.put(m.name, v.toDouble())
        return JSONObject()
            .put("needs", needs.toJson())
            .put("mood", mood.name)
            .put("intensity", intensity.toDouble())
            .put("boosts", b)
            .put("lastMessageAt", lastMessageAt)
            .put("lastTickAt", lastTickAt)
            .toString()
    }

    companion object {
        fun initial(now: Long) = MoodState(
            needs = Needs(),
            mood = Mood.CURIOUS,
            intensity = 0.5f,
            boosts = emptyMap(),
            lastMessageAt = now,
            lastTickAt = now,
        )

        fun fromJson(json: String?, now: Long): MoodState {
            if (json.isNullOrBlank()) return initial(now)
            return try {
                val o = JSONObject(json)
                val boosts = HashMap<Mood, Float>()
                val bo = o.optJSONObject("boosts")
                if (bo != null) {
                    for (key in bo.keys()) {
                        val mood = Mood.fromName(key)
                        if (mood != null) boosts[mood] = bo.optDouble(key).toFloat()
                    }
                }
                MoodState(
                    needs = Needs.fromJson(o.optJSONObject("needs")),
                    mood = Mood.fromName(o.optString("mood")) ?: Mood.CURIOUS,
                    intensity = o.optDouble("intensity", 0.5).toFloat(),
                    boosts = boosts,
                    lastMessageAt = o.optLong("lastMessageAt", now),
                    lastTickAt = o.optLong("lastTickAt", now),
                )
            } catch (e: Exception) {
                initial(now)
            }
        }
    }
}
