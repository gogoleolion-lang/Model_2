package com.sherley.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sherley.app.avatar.AvatarBody
import com.sherley.app.avatar.BodyLayouts
import com.sherley.app.avatar.JointCalibration
import com.sherley.app.avatar.Pose
import kotlin.math.roundToInt

private val LABELS = mapOf(
    "top" to "Top of head", "head" to "Head center", "neck" to "Neck",
    "shL" to "Shoulder (right of screen)", "shR" to "Shoulder (left of screen)",
    "elL" to "Elbow (right of screen)", "elR" to "Elbow (left of screen)",
    "wrL" to "Wrist (right of screen)", "wrR" to "Wrist (left of screen)",
)

/**
 * Joint calibration. Dots start where the app guesses her joints are; drag each one onto the real
 * joint on her body, then Save. Do this while she stands naturally and the camera is in its default place.
 */
@Composable
fun JointCalibrator(
    body: AvatarBody?,
    minRadiusPx: Float,
    onSave: (JointCalibration) -> Unit,
    onReset: () -> Unit,
    onCancel: () -> Unit,
) {
    val dots = remember { mutableStateMapOf<String, Offset>() }
    var failed by remember { mutableStateOf(false) }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val w = constraints.maxWidth.toFloat()
        val h = constraints.maxHeight.toFloat()
        val density = LocalDensity.current

        // Start from the built-in guess once the camera has been put back to its default place.
        LaunchedEffect(body) {
            body?.resetCamera()
            kotlinx.coroutines.delay(400)
            val layout = body?.let { BodyLayouts.compute(it, Pose.natural, w, h, minRadiusPx, null) }
            if (layout == null) failed = true
            else JointCalibration.KEYS.forEach { k -> layout.points[k]?.let { dots[k] = Offset(it.x, it.y) } }
        }

        for ((key, pos) in dots) {
            Box(
                Modifier
                    .offset { IntOffset((pos.x - with(density) { 14.dp.toPx() }).roundToInt(), (pos.y - with(density) { 14.dp.toPx() }).roundToInt()) }
                    .size(28.dp)
                    .background(Color(0xCCFFD400), CircleShape)
                    .pointerInput(key) {
                        detectDragGestures { change, drag ->
                            change.consume()
                            dots[key] = (dots[key] ?: pos) + drag
                        }
                    },
            )
            Text(
                LABELS[key].orEmpty(),
                color = Color.White,
                fontSize = 10.sp,
                modifier = Modifier
                    .offset { IntOffset((pos.x + with(density) { 18.dp.toPx() }).roundToInt(), (pos.y - with(density) { 8.dp.toPx() }).roundToInt()) }
                    .background(Color(0x99000000)),
            )
        }

        Column(
            Modifier
                .align(Alignment.TopCenter)
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(16.dp)
                .background(Color(0xDD1B2A55)),
        ) {
            Text(
                if (failed) "Could not find her on screen yet. Wait for the model to load, then try again."
                else "Drag each yellow dot onto the matching joint on her body. Your saved pose is cleared for this.",
                color = Color.White,
                modifier = Modifier.padding(10.dp),
                fontSize = 13.sp,
            )
            Row(Modifier.padding(10.dp)) {
                Button(onClick = {
                    val b = body ?: return@Button
                    val feet = b.feetWorld() ?: return@Button
                    val aspect = w / h
                    val pts = mutableMapOf<String, FloatArray>()
                    for (k in JointCalibration.KEYS) {
                        val d = dots[k] ?: return@Button
                        val world = b.unproject(d.x / w, d.y / h, aspect, feet[2]) ?: return@Button
                        pts[k] = floatArrayOf(world[0] - feet[0], world[1] - feet[1])
                    }
                    val height = pts.getValue("top")[1]
                    if (height < 0.2f) return@Button
                    onSave(JointCalibration(height, pts))
                }) { Text("Save") }
                OutlinedButton(onClick = onReset, modifier = Modifier.padding(start = 8.dp)) { Text("Use defaults", color = Color.White) }
                OutlinedButton(onClick = onCancel, modifier = Modifier.padding(start = 8.dp)) { Text("Cancel", color = Color.White) }
            }
        }
    }
}
