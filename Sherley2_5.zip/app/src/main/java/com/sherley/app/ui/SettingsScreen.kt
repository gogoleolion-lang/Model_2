package com.sherley.app.ui

import androidx.compose.foundation.background
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.sherley.app.avatar.AvatarModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** Chat model, avatar, names, memory. Every field saves as you type. */
@Composable
fun SettingsScreen(vm: ChatViewModel, onBack: () -> Unit, onCalibrate: () -> Unit) {
    val s = vm.settings
    val scope0 = rememberCoroutineScope()
    val ui by vm.ui.collectAsStateWithLifecycle()

    var localUrl by remember { mutableStateOf(s.localUrl) }
    var localModel by remember { mutableStateOf(s.localModel) }
    val context = LocalContext.current
    var avatarOn by remember { mutableStateOf(s.avatarEnabled) }
    var faceStrength by remember { mutableStateOf(s.faceStrength) }
    var eyeFollow by remember { mutableStateOf(s.eyeFollow) }
    var devMode by remember { mutableStateOf(s.devMode) }
    var bgBehind by remember { mutableStateOf(s.bgBehindAvatar) }
    var pickResult by remember { mutableStateOf("") }
    val pickVrm = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope0.launch {
                pickResult = "Copying…"
                val ok = withContext(Dispatchers.IO) { AvatarModel.importFrom(context, uri) }
                pickResult = if (ok) "Model copied. Reloading her." else "Could not read that file."
                if (ok) vm.bumpAvatar()
            }
        }
    }
    var userName by remember { mutableStateOf(s.userName) }
    var historyTurns by remember { mutableStateOf(s.historyTurns.toString()) }
    var confirmClear by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .windowInsetsPadding(WindowInsets.safeDrawing)
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        TextButton(onClick = onBack) { Text("← Back", fontSize = 16.sp) }
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        Section("Chat model (Thinai, runs on this phone)")
        Field("Server address", localUrl) { localUrl = it; s.localUrl = it }
        Field("Model name (leave empty to use the first one Thinai has)", localModel) {
            localModel = it
            s.localModel = it
        }

        OutlinedButton(
            onClick = {
                testing = true
                testResult = "Testing…"
                scope.launch {
                    testResult = vm.testConnection()
                    testing = false
                }
            },
            enabled = !testing,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        ) { Text("Test Thinai connection") }
        if (testResult.isNotBlank()) {
            Text(testResult, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
        }

        Section("Avatar (3D body)")
        SwitchRow("Show her 3D body", avatarOn) { avatarOn = it; s.avatarEnabled = it }
        OutlinedButton(
            onClick = { pickVrm.launch(arrayOf("*/*")) },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        ) { Text("Pick a .vrm model file") }
        OutlinedButton(
            onClick = { AvatarModel.clearPicked(context); vm.bumpAvatar(); pickResult = "Picked file removed." },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
        ) { Text("Use the bundled model instead") }
        if (pickResult.isNotBlank()) Text(pickResult, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp))
        Text("Face expression strength: ${(faceStrength * 100).toInt()}% (0 = keep the model's own face)", fontSize = 14.sp, modifier = Modifier.padding(top = 12.dp))
        Slider(value = faceStrength, onValueChange = { faceStrength = it; s.faceStrength = it })
        OutlinedButton(onClick = onCalibrate, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Text("Calibrate joints (makes touch and posing accurate)")
        }
        SwitchRow("Eyes follow my finger (experimental)", eyeFollow) { eyeFollow = it; s.eyeFollow = it }
        SwitchRow("Draw mood background behind her (may hide her)", bgBehind) { bgBehind = it; s.bgBehindAvatar = it }
        SwitchRow("Developer overlay (joint dots + model info)", devMode) { devMode = it; s.devMode = it }
        Text(
            "Touch reacts on her head, neck, shoulders, arms and hands (36 reactions). Tap, double-tap, stroke, or tap repeatedly. Long-press a joint to pose her.",
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 8.dp),
        )

        Section("You")
        Field("Your name (what Sherley calls you)", userName) { userName = it; s.userName = it }

        Section("Memory")
        NumberField("Recent turns sent with each message (2 to 30)", historyTurns) {
            historyTurns = it
            it.toIntOrNull()?.let { n -> s.historyTurns = n }
        }
        OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Clear history, memories and mood")
        }

        Section("Mood meter (read-only, for tuning)")
        val n = ui.needs
        Text(
            text = "Mood: ${ui.mood.label} (${(ui.intensity * 100).roundToInt()}%)\n" +
                "Energy ${n.energy.roundToInt()}  ·  Stimulation ${n.stimulation.roundToInt()}  ·  " +
                "Company ${n.company.roundToInt()}\n" +
                "Respect ${n.respect.roundToInt()}  ·  Comfort ${n.comfort.roundToInt()}  ·  " +
                "Confidence ${n.confidence.roundToInt()}",
            fontSize = 14.sp,
        )
        Spacer(Modifier.height(24.dp))
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text("Clear everything?") },
            text = { Text("This deletes the whole conversation, everything Sherley remembered about you, and resets her mood. Backgrounds and settings stay.") },
            confirmButton = {
                TextButton(onClick = { vm.clearEverything(); confirmClear = false }) { Text("Clear") }
            },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(20.dp))
    Text(title, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
    )
}

@Composable
private fun NumberField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit)) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
    )
}
