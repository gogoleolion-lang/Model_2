package com.sherley.app.avatar

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.hypot

/**
 * Where her joints really are, measured once by you (Settings > Calibrate joints) while she stands in
 * her natural pose with the camera in its default place. Every point is stored as a world-space offset
 * from her feet, so it follows her when the camera moves.
 *
 * Keys: top (top of head), head, neck, shL, shR (shoulders), elL, elR (elbows), wrL, wrR (wrists).
 * "L" is her left, which is the right side of the screen.
 */
class JointCalibration(val height: Float, val pts: Map<String, FloatArray>) {

    fun toJson(): String {
        val o = JSONObject().put("h", height.toDouble())
        val p = JSONObject()
        for ((k, v) in pts) p.put(k, JSONArray().put(v[0].toDouble()).put(v[1].toDouble()))
        return o.put("pts", p).toString()
    }

    /** The arm directions implied by the measured joints: how her idle animation really holds her arms. */
    fun naturalPose(): Pose? {
        val shL = pts["shL"] ?: return null
        val elL = pts["elL"] ?: return null
        val wrL = pts["wrL"] ?: return null
        val shR = pts["shR"] ?: return null
        val elR = pts["elR"] ?: return null
        val wrR = pts["wrR"] ?: return null
        fun dir(a: FloatArray, b: FloatArray, forward: Float): FloatArray {
            val dx = b[0] - a[0]
            val dy = b[1] - a[1]
            return V.norm(dx, dy, forward * hypot(dx, dy))
        }
        return Pose(
            head = V.head(0f, 0f),
            lUpper = dir(shL, elL, 0f), lLower = dir(elL, wrL, 0.12f),
            rUpper = dir(shR, elR, 0f), rLower = dir(elR, wrR, 0.12f),
        )
    }

    companion object {
        val KEYS = listOf("top", "head", "neck", "shL", "shR", "elL", "elR", "wrL", "wrR")

        fun fromJson(json: String?): JointCalibration? {
            if (json.isNullOrBlank()) return null
            return try {
                val o = JSONObject(json)
                val p = o.getJSONObject("pts")
                val map = KEYS.associateWith { k -> p.getJSONArray(k).let { floatArrayOf(it.getDouble(0).toFloat(), it.getDouble(1).toFloat()) } }
                JointCalibration(o.getDouble("h").toFloat(), map)
            } catch (e: Exception) {
                null
            }
        }
    }
}
