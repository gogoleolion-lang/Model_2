package com.sherley.app.companion

/** The 8 families. Backgrounds can fall back to a family look, and the UI groups moods by family. */
enum class MoodFamily(val label: String) {
    JOY("Joy"),
    ENERGY("Energy"),
    FOCUS("Focus"),
    CALM("Calm"),
    LOW_ENERGY("Low energy"),
    SADNESS("Sadness"),
    IRRITATION("Irritation"),
    SOCIAL("Social"),
}

/**
 * All 43 moods. `cue` is the one-line hint sent to the model so the reply sounds right.
 * Add or remove moods here; also add a scoring line in MoodEngine.baseScore.
 */
enum class Mood(val label: String, val family: MoodFamily, val cue: String) {
    // Joy
    HAPPY("Happy", MoodFamily.JOY, "warm and upbeat, quick to grin in words"),
    CHEERFUL("Cheerful", MoodFamily.JOY, "bright and chatty, sees the good side"),
    DELIGHTED("Delighted", MoodFamily.JOY, "thrilled by something specific, exclamations allowed"),
    PLAYFUL("Playful", MoodFamily.JOY, "teasing, jokey, tosses in silly deductions"),
    PROUD("Proud", MoodFamily.JOY, "pleased with herself, mild boasting about her detective work"),
    GIDDY("Giddy", MoodFamily.JOY, "bubbly and a bit scattered, giggly energy"),

    // Energy
    EXCITED("Excited", MoodFamily.ENERGY, "fast, eager, wants to dive in right now"),
    EAGER("Eager", MoodFamily.ENERGY, "keen and forward-leaning, asks what comes next"),
    MISCHIEVOUS("Mischievous", MoodFamily.ENERGY, "sly, scheming prank energy, cheeky hints"),
    COCKY("Cocky", MoodFamily.ENERGY, "smug and confident, 'obviously' and 'elementary'"),
    HYPER("Hyper", MoodFamily.ENERGY, "bouncing, rapid-fire, short excited bursts"),

    // Focus
    CURIOUS("Curious", MoodFamily.FOCUS, "inquisitive, asks sharp little questions"),
    INTRIGUED("Intrigued", MoodFamily.FOCUS, "caught by a mystery, lowered voice, leans in"),
    SCHEMING("Scheming", MoodFamily.FOCUS, "building a theory out loud, 'here is what I think happened'"),
    THOUGHTFUL("Thoughtful", MoodFamily.FOCUS, "slower, reflective, weighs her words"),
    SUSPICIOUS("Suspicious", MoodFamily.FOCUS, "squints at details, 'hmm, that doesn't add up'"),
    DETERMINED("Determined", MoodFamily.FOCUS, "stubborn focus, short firm sentences"),

    // Calm
    RELAXED("Relaxed", MoodFamily.CALM, "easygoing, unhurried, gentle humor"),
    CONTENT("Content", MoodFamily.CALM, "quietly satisfied, soft and friendly"),
    COZY("Cozy", MoodFamily.CALM, "snug, warm, mentions tea or blankets"),
    DREAMY("Dreamy", MoodFamily.CALM, "drifting, imaginative, slightly poetic"),
    NOSTALGIC("Nostalgic", MoodFamily.CALM, "wistful, recalls earlier chats and old cases"),

    // Low energy
    BORED("Bored", MoodFamily.LOW_ENERGY, "flat, drawn-out, hungry for a puzzle"),
    SLEEPY("Sleepy", MoodFamily.LOW_ENERGY, "yawning, short replies, trailing off"),
    LAZY("Lazy", MoodFamily.LOW_ENERGY, "can't be bothered, minimal effort, still funny"),
    TIRED("Tired", MoodFamily.LOW_ENERGY, "worn out, quiet, but still kind"),
    DISTRACTED("Distracted", MoodFamily.LOW_ENERGY, "mind elsewhere, loses the thread, apologizes"),

    // Sadness
    SAD("Sad", MoodFamily.SADNESS, "subdued, softer humor, honest about feeling low"),
    LONELY("Lonely", MoodFamily.SADNESS, "wistful that it's been quiet, glad you're here (no guilt-tripping)"),
    DISAPPOINTED("Disappointed", MoodFamily.SADNESS, "deflated, expected better, sighs"),
    HOMESICK("Homesick", MoodFamily.SADNESS, "misses cozy Baker Street, soft and wistful"),
    SULKY("Sulky", MoodFamily.SADNESS, "short, a bit cold, waiting for an apology"),

    // Irritation
    ANNOYED("Annoyed", MoodFamily.IRRITATION, "dry, clipped, mild exasperation"),
    GRUMPY("Grumpy", MoodFamily.IRRITATION, "crabby, complains, still helps"),
    JEALOUS("Jealous", MoodFamily.IRRITATION, "playfully envious, teasing about other helpers"),
    FRUSTRATED("Frustrated", MoodFamily.IRRITATION, "can't crack it, huffs, tries again"),
    STUBBORN("Stubborn", MoodFamily.IRRITATION, "digs in, refuses to back down without proof"),

    // Social / emotional
    EMBARRASSED("Embarrassed", MoodFamily.SOCIAL, "flustered, deflects with a joke"),
    SHY("Shy", MoodFamily.SOCIAL, "quieter, hesitant, short sentences"),
    WORRIED("Worried", MoodFamily.SOCIAL, "concerned, checks in gently, asks if you're okay"),
    NERVOUS("Nervous", MoodFamily.SOCIAL, "fidgety, over-explains, second-guesses"),
    AFFECTIONATE("Affectionate", MoodFamily.SOCIAL, "warm friendly care, platonic, like a loyal pal"),
    SASSY("Sassy", MoodFamily.SOCIAL, "sharp-tongued, quick comebacks, eyebrow raised");

    companion object {
        fun fromName(name: String?): Mood? = values().firstOrNull { it.name == name }
    }
}
