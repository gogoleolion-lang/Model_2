package com.sherley.app.avatar

import android.content.Context
import android.net.Uri
import java.io.File

/**
 * Where her VRM file comes from. A file you picked in Settings (copied to the app's private
 * storage) wins over one bundled in app/src/main/assets/vrms/.
 */
object AvatarModel {

    private fun picked(context: Context) = File(context.filesDir, "avatar.vrm")

    fun pickedFile(context: Context): File? = picked(context).takeIf { it.exists() && it.length() > 0 }

    /** First .vrm in assets/vrms, as a path the SDK understands ("vrms/name.vrm"). */
    fun bundledAsset(context: Context): String? =
        context.assets.list("vrms")?.firstOrNull { it.endsWith(".vrm", true) }?.let { "vrms/$it" }

    fun hasModel(context: Context) = pickedFile(context) != null || bundledAsset(context) != null

    /** Copies the chosen file into private storage. Returns true on success. */
    fun importFrom(context: Context, uri: Uri): Boolean = try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            picked(context).outputStream().use { input.copyTo(it) }
        } != null
    } catch (e: Exception) {
        false
    }

    fun clearPicked(context: Context) { picked(context).delete() }
}
