package com.sherley.app.ai

import com.sherley.app.companion.ChatEvent

/** Anything that goes wrong talking to the local server. The message is shown to the user as-is. */
class ApiException(message: String) : Exception(message)

/** One message sent to the language model. role is "user" or "model". */
data class Turn(val role: String, val text: String)

/** What the language model returned for one chat message. */
data class ChatResult(
    val reply: String,
    val events: List<ChatEvent>,
    val facts: List<String>,
)
