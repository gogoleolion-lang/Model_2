package com.sherley.app.avatar

import android.os.SystemClock
import com.neethu.corelib.MimicPose
import org.json.JSONArray
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/** Small vector helpers. A direction is a unit FloatArray(3): +X screen right, +Y up, +Z toward the viewer. */
object V {
    fun norm(x: Float, y: Float, z: Float): FloatArray {
        val l = sqrt(x * x + y * y + z * z).coerceAtLeast(1e-6f)
        return floatArrayOf(x / l, y / l, z / l)
    }

    fun cross(a: FloatArray, b: FloatArray) = floatArrayOf(
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )

    /**
     * An arm direction. side +1 = her left arm (screen right), -1 = her right arm.
     * elevation: 0 = hanging down, 90 = straight out, 180 = straight up.
     * forward: 0 = in the body plane, 90 = pointing toward the viewer.
     */
    fun arm(side: Int, elevation: Float, forward: Float = 0f): FloatArray {
        val e = Math.toRadians(elevation.toDouble())
        val f = Math.toRadians(forward.toDouble())
        return norm((side * sin(e) * cos(f)).toFloat(), (-cos(e)).toFloat(), (sin(e) * sin(f)).toFloat())
    }

    /** A head-facing direction. yaw + = toward screen right, pitch + = looking up (degrees). */
    fun head(yaw: Float, pitch: Float): FloatArray {
        val y = Math.toRadians(yaw.toDouble())
        val p = Math.toRadians(pitch.toDouble())
        return norm((sin(y) * cos(p)).toFloat(), sin(p).toFloat(), (cos(y) * cos(p)).toFloat())
    }
}

/** Where her head and both arms point. The library turns these directions into bone rotations. */
class Pose(
    val head: FloatArray,
    val lUpper: FloatArray,
    val lLower: FloatArray,
    val rUpper: FloatArray,
    val rLower: FloatArray,
) {
    fun withHead(h: FloatArray) = Pose(h, lUpper, lLower, rUpper, rLower)

    /** Replaces one side's arm. A null part keeps its current direction. */
    fun arm(side: Int, upper: FloatArray? = null, lower: FloatArray? = null): Pose =
        if (side >= 0) Pose(head, upper ?: lUpper, lower ?: lLower, rUpper, rLower)
        else Pose(head, lUpper, lLower, upper ?: rUpper, lower ?: rLower)

    fun toMimic() = MimicPose(
        timestampMs = SystemClock.elapsedRealtime(),
        headForward = head,
        leftUpperArm = lUpper,
        leftLowerArm = lLower,
        rightUpperArm = rUpper,
        rightLowerArm = rLower,
        torsoAxis = null,
        shoulderLine = null,
        visible = true,
    )

    fun toJson(): String {
        val a = JSONArray()
        for (v in listOf(head, lUpper, lLower, rUpper, rLower)) for (x in v) a.put(x.toDouble())
        return a.toString()
    }

    companion object {
        /** Roughly how her idle animation holds her: arms hanging, slightly out and forward. */
        private val DEFAULT_NATURAL = Pose(
            head = V.head(0f, 0f),
            lUpper = V.arm(1, 22f),
            lLower = V.arm(1, 28f, 14f),
            rUpper = V.arm(-1, 22f),
            rLower = V.arm(-1, 28f, 14f),
        )

        /** The pose she holds when idle. Replaced by your joint calibration when there is one. */
        @Volatile
        var natural: Pose = DEFAULT_NATURAL
            private set

        fun applyCalibration(cal: JointCalibration?) {
            natural = cal?.naturalPose() ?: DEFAULT_NATURAL
        }

        fun fromJson(json: String?): Pose? {
            if (json.isNullOrBlank()) return null
            return try {
                val a = JSONArray(json)
                if (a.length() != 15) return null
                fun v(i: Int) = V.norm(a.getDouble(i * 3).toFloat(), a.getDouble(i * 3 + 1).toFloat(), a.getDouble(i * 3 + 2).toFloat())
                Pose(v(0), v(1), v(2), v(3), v(4))
            } catch (e: Exception) {
                null
            }
        }
    }
}
